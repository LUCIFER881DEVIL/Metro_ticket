package com.metro.metro_ticket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetroTicketApplication {

	public static void main(String[] args) {
		SpringApplication.run(MetroTicketApplication.class, args);
	}

}
