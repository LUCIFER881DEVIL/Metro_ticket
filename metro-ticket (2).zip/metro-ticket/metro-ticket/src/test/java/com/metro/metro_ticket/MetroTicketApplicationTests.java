package com.metro.metro_ticket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MetroTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
